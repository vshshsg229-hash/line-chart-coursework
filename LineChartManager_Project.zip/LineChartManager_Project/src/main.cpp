#include <QApplication>
#include <QMainWindow>
#include <QWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QPushButton>
#include <QLineEdit>
#include <QTextEdit>
#include <QDateEdit>
#include <QDoubleSpinBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QHeaderView>
#include <QPainter>
#include <QLabel>
#include <QComboBox>
#include <QDate>
#include <QStringConverter>

const int МаксимумЗаписів = 1000;

struct Запис {
    QString Назва;
    double Значення;
    QString Дата;
    QString Опис;
};

class ВікноДіаграми : public QWidget {
public:
    ВікноДіаграми(const Запис дані[], int кількістьДаних, QWidget *батько = nullptr)
        : QWidget(батько), записи(дані), кількість(кількістьДаних) {
        setWindowTitle(QStringLiteral("Лінійчата діаграма"));
        resize(760, 480);
    }
protected:
    void paintEvent(QPaintEvent *) override {
        QPainter маляр(this);
        маляр.setRenderHint(QPainter::Antialiasing);
        маляр.fillRect(rect(), QColor(250, 250, 250));
        маляр.setPen(Qt::black);
        маляр.drawText(QRect(20, 10, width()-40, 30), Qt::AlignCenter,
                       QStringLiteral("Лінійчата діаграма значень"));
        if (кількість <= 0) {
            маляр.drawText(rect(), Qt::AlignCenter, QStringLiteral("Немає даних для побудови"));
            return;
        }
        double найбільше = 0.0;
        for (int i=0; i<кількість; ++i)
            if (записи[i].Значення > найбільше) найбільше = записи[i].Значення;
        if (найбільше <= 0.0) найбільше = 1.0;
        const int лівийКрай = 190;
        const int правийКрай = width()-40;
        const int верх = 55;
        const int висотаРядка = qMax(28, (height()-85)/кількість);
        маляр.drawLine(лівийКрай, верх-5, лівийКрай, height()-25);
        for (int i=0; i<кількість; ++i) {
            int y = верх+i*висотаРядка;
            int довжина = static_cast<int>((записи[i].Значення/найбільше)*
                                            (правийКрай-лівийКрай));
            маляр.drawText(QRect(8,y,лівийКрай-18,висотаРядка-2),
                           Qt::AlignRight|Qt::AlignVCenter, записи[i].Назва);
            маляр.fillRect(лівийКрай+1,y+4,qMax(1,довжина),висотаРядка-9,
                           QColor(42,115,190));
            маляр.setPen(Qt::black);
            маляр.drawText(лівийКрай+довжина+6,y+висотаРядка/2+5,
                           QString::number(записи[i].Значення,'g',8));
        }
    }
private:
    const Запис *записи;
    int кількість;
};

class ФормаЗапису : public QDialog {
public:
    explicit ФормаЗапису(QWidget *батько=nullptr) : QDialog(батько) {
        setWindowTitle(QStringLiteral("Дані запису"));
        назва = new QLineEdit(this);
        значення = new QDoubleSpinBox(this);
        значення->setRange(0.0,1000000000.0);
        значення->setDecimals(3);
        дата = new QDateEdit(QDate::currentDate(),this);
        дата->setCalendarPopup(true);
        опис = new QTextEdit(this);
        опис->setMaximumHeight(90);
        QFormLayout *форма = new QFormLayout;
        форма->addRow(QStringLiteral("Назва категорії:"),назва);
        форма->addRow(QStringLiteral("Числове значення:"),значення);
        форма->addRow(QStringLiteral("Дата:"),дата);
        форма->addRow(QStringLiteral("Опис:"),опис);
        QDialogButtonBox *кнопки = new QDialogButtonBox(
            QDialogButtonBox::Ok|QDialogButtonBox::Cancel,this);
        connect(кнопки,&QDialogButtonBox::accepted,this,&QDialog::accept);
        connect(кнопки,&QDialogButtonBox::rejected,this,&QDialog::reject);
        QVBoxLayout *основа = new QVBoxLayout(this);
        основа->addLayout(форма); основа->addWidget(кнопки);
    }
    void встановити(const Запис &елемент) {
        назва->setText(елемент.Назва);
        значення->setValue(елемент.Значення);
        дата->setDate(QDate::fromString(елемент.Дата,Qt::ISODate));
        опис->setPlainText(елемент.Опис);
    }
    Запис отримати() const {
        Запис елемент;
        елемент.Назва=назва->text().trimmed();
        елемент.Значення=значення->value();
        елемент.Дата=дата->date().toString(Qt::ISODate);
        елемент.Опис=опис->toPlainText().trimmed();
        return елемент;
    }
private:
    QLineEdit *назва;
    QDoubleSpinBox *значення;
    QDateEdit *дата;
    QTextEdit *опис;
};

class ГоловнеВікно : public QMainWindow {
public:
    ГоловнеВікно() {
        setWindowTitle(QStringLiteral("Менеджер даних лінійчатих діаграм"));
        resize(1000,650);
        таблиця=new QTableWidget(0,4,this);
        таблиця->setHorizontalHeaderLabels(QStringList()
            <<QStringLiteral("Назва")<<QStringLiteral("Значення")
            <<QStringLiteral("Дата")<<QStringLiteral("Опис"));
        таблиця->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        таблиця->setSelectionBehavior(QAbstractItemView::SelectRows);
        таблиця->setSelectionMode(QAbstractItemView::SingleSelection);
        таблиця->setEditTriggers(QAbstractItemView::NoEditTriggers);
        пошук=new QLineEdit(this);
        пошук->setPlaceholderText(QStringLiteral("Пошук за будь-яким полем..."));
        полеСортування=new QComboBox(this);
        полеСортування->addItems(QStringList()<<QStringLiteral("Назва")
            <<QStringLiteral("Значення")<<QStringLiteral("Дата")<<QStringLiteral("Опис"));
        QPushButton *додати=new QPushButton(QStringLiteral("Додати запис"),this);
        QPushButton *редагувати=new QPushButton(QStringLiteral("Редагувати"),this);
        QPushButton *видалити=new QPushButton(QStringLiteral("Видалити"),this);
        QPushButton *сортувати=new QPushButton(QStringLiteral("Сортувати"),this);
        QPushButton *зберегти=new QPushButton(QStringLiteral("Зберегти у файл"),this);
        QPushButton *завантажити=new QPushButton(QStringLiteral("Завантажити з файлу"),this);
        QPushButton *діаграма=new QPushButton(QStringLiteral("Побудувати діаграму"),this);
        QPushButton *показати=new QPushButton(QStringLiteral("Показати всі"),this);
        QHBoxLayout *рядокПошуку=new QHBoxLayout;
        рядокПошуку->addWidget(new QLabel(QStringLiteral("Пошук:"),this));
        рядокПошуку->addWidget(пошук); рядокПошуку->addWidget(показати);
        QHBoxLayout *рядокКнопок=new QHBoxLayout;
        рядокКнопок->addWidget(додати); рядокКнопок->addWidget(редагувати);
        рядокКнопок->addWidget(видалити);
        рядокКнопок->addWidget(new QLabel(QStringLiteral("Поле:"),this));
        рядокКнопок->addWidget(полеСортування); рядокКнопок->addWidget(сортувати);
        QHBoxLayout *рядокФайлу=new QHBoxLayout;
        рядокФайлу->addWidget(зберегти); рядокФайлу->addWidget(завантажити);
        рядокФайлу->addWidget(діаграма);
        QWidget *центральний=new QWidget(this);
        QVBoxLayout *основа=new QVBoxLayout(центральний);
        основа->addLayout(рядокПошуку); основа->addWidget(таблиця);
        основа->addLayout(рядокКнопок); основа->addLayout(рядокФайлу);
        setCentralWidget(центральний);
        connect(додати,&QPushButton::clicked,this,[this](){додатиЗапис();});
        connect(редагувати,&QPushButton::clicked,this,[this](){редагуватиЗапис();});
        connect(видалити,&QPushButton::clicked,this,[this](){видалитиЗапис();});
        connect(сортувати,&QPushButton::clicked,this,[this](){сортуватиЗаписи();});
        connect(зберегти,&QPushButton::clicked,this,[this](){зберегтиФайл();});
        connect(завантажити,&QPushButton::clicked,this,[this](){завантажитиФайл();});
        connect(діаграма,&QPushButton::clicked,this,[this](){показатиДіаграму();});
        connect(показати,&QPushButton::clicked,this,[this](){пошук->clear();оновитиТаблицю();});
        connect(пошук,&QLineEdit::textChanged,this,[this](){оновитиТаблицю();});
        додатиПочатковіЗаписи(); оновитиТаблицю();
    }
private:
    Запис записи[МаксимумЗаписів];
    int кількість=0;
    QTableWidget *таблиця;
    QLineEdit *пошук;
    QComboBox *полеСортування;

    void додатиПочатковіЗаписи() {
        const QString назви[10]={QStringLiteral("Математика"),QStringLiteral("Інформатика"),
            QStringLiteral("Фізика"),QStringLiteral("Історія"),QStringLiteral("Українська мова"),
            QStringLiteral("Біологія"),QStringLiteral("Географія"),QStringLiteral("Хімія"),
            QStringLiteral("Англійська мова"),QStringLiteral("Мистецтво")};
        const double значення[10]={85,94,78,82,91,76,88,73,96,89};
        for(int i=0;i<10;++i) {
            записи[кількість].Назва=назви[i];
            записи[кількість].Значення=значення[i];
            записи[кількість].Дата=QDate::currentDate().toString(Qt::ISODate);
            записи[кількість].Опис=QStringLiteral("Демонстраційний запис");
            ++кількість;
        }
    }
    void оновитиТаблицю() {
        таблиця->setRowCount(0);
        QString запит=пошук->text().trimmed();
        for(int i=0;i<кількість;++i) {
            QString рядокДаних=записи[i].Назва+" "+
                QString::number(записи[i].Значення,'g',12)+" "+
                записи[i].Дата+" "+записи[i].Опис;
            if(!запит.isEmpty()&&!рядокДаних.contains(запит,Qt::CaseInsensitive)) continue;
            int рядок=таблиця->rowCount(); таблиця->insertRow(рядок);
            таблиця->setItem(рядок,0,new QTableWidgetItem(записи[i].Назва));
            таблиця->setItem(рядок,1,new QTableWidgetItem(QString::number(записи[i].Значення,'g',12)));
            таблиця->setItem(рядок,2,new QTableWidgetItem(записи[i].Дата));
            таблиця->setItem(рядок,3,new QTableWidgetItem(записи[i].Опис));
            таблиця->item(рядок,0)->setData(Qt::UserRole,i);
        }
    }
    int вибранийІндекс() const {
        int рядок=таблиця->currentRow();
        if(рядок<0||таблиця->item(рядок,0)==nullptr) return -1;
        return таблиця->item(рядок,0)->data(Qt::UserRole).toInt();
    }
    void додатиЗапис() {
        if(кількість>=МаксимумЗаписів) {
            QMessageBox::warning(this,QStringLiteral("Обмеження"),QStringLiteral("Досягнуто максимальної кількості записів."));
            return;
        }
        ФормаЗапису форма(this);
        if(форма.exec()==QDialog::Accepted) {
            Запис елемент=форма.отримати();
            if(елемент.Назва.isEmpty()) {
                QMessageBox::warning(this,QStringLiteral("Помилка"),QStringLiteral("Назва не може бути порожньою."));
                return;
            }
            записи[кількість]=елемент; ++кількість; оновитиТаблицю();
        }
    }
    void редагуватиЗапис() {
        int індекс=вибранийІндекс();
        if(індекс<0) { QMessageBox::information(this,QStringLiteral("Редагування"),QStringLiteral("Спочатку виберіть запис.")); return; }
        ФормаЗапису форма(this); форма.встановити(записи[індекс]);
        if(форма.exec()==QDialog::Accepted) {
            Запис елемент=форма.отримати();
            if(елемент.Назва.isEmpty()) { QMessageBox::warning(this,QStringLiteral("Помилка"),QStringLiteral("Назва не може бути порожньою.")); return; }
            записи[індекс]=елемент; оновитиТаблицю();
        }
    }
    void видалитиЗапис() {
        int індекс=вибранийІндекс();
        if(індекс<0) { QMessageBox::information(this,QStringLiteral("Видалення"),QStringLiteral("Спочатку виберіть запис.")); return; }
        if(QMessageBox::question(this,QStringLiteral("Підтвердження"),QStringLiteral("Видалити вибраний запис?"))!=QMessageBox::Yes) return;
        for(int i=індекс;i<кількість-1;++i) записи[i]=записи[i+1];
        --кількість; оновитиТаблицю();
    }
    void сортуватиЗаписи() {
        int поле=полеСортування->currentIndex();
        for(int i=0;i<кількість-1;++i) for(int j=0;j<кількість-i-1;++j) {
            bool поміняти=false;
            if(поле==0) поміняти=QString::compare(записи[j].Назва,записи[j+1].Назва,Qt::CaseInsensitive)>0;
            else if(поле==1) поміняти=записи[j].Значення>записи[j+1].Значення;
            else if(поле==2) поміняти=записи[j].Дата>записи[j+1].Дата;
            else поміняти=QString::compare(записи[j].Опис,записи[j+1].Опис,Qt::CaseInsensitive)>0;
            if(поміняти) { Запис тимчасовий=записи[j]; записи[j]=записи[j+1]; записи[j+1]=тимчасовий; }
        }
        оновитиТаблицю();
    }
    void зберегтиФайл() {
        QString шлях=QFileDialog::getSaveFileName(this,QStringLiteral("Зберегти дані"),QString(),QStringLiteral("CSV (*.csv)"));
        if(шлях.isEmpty()) return;
        QFile файл(шлях);
        if(!файл.open(QIODevice::WriteOnly|QIODevice::Text)) {
            QMessageBox::critical(this,QStringLiteral("Помилка"),QStringLiteral("Не вдалося відкрити файл для запису.")); return;
        }
        QTextStream потік(&файл); потік.setEncoding(QStringConverter::Utf8);
        потік<<"Назва;Значення;Дата;Опис\n";
        for(int i=0;i<кількість;++i) {
            QString опис=записи[i].Опис; опис.replace(';',','); опис.replace('\n',' ');
            потік<<записи[i].Назва<<';'<<QString::number(записи[i].Значення,'g',12)<<';'
                 <<записи[i].Дата<<';'<<опис<<'\n';
        }
        файл.close();
        QMessageBox::information(this,QStringLiteral("Збереження"),QStringLiteral("Дані успішно збережено."));
    }
    void завантажитиФайл() {
        QString шлях=QFileDialog::getOpenFileName(this,QStringLiteral("Завантажити дані"),QString(),QStringLiteral("CSV (*.csv)"));
        if(шлях.isEmpty()) return;
        QFile файл(шлях);
        if(!файл.open(QIODevice::ReadOnly|QIODevice::Text)) {
            QMessageBox::critical(this,QStringLiteral("Помилка"),QStringLiteral("Не вдалося відкрити файл.")); return;
        }
        QTextStream потік(&файл); потік.setEncoding(QStringConverter::Utf8);
        потік.readLine();
        Запис тимчасові[МаксимумЗаписів]; int новаКількість=0;
        while(!потік.atEnd()&&новаКількість<МаксимумЗаписів) {
            QString рядок=потік.readLine(); QStringList частини=рядок.split(';');
            if(частини.size()<4) continue;
            bool коректнеЧисло=false; double число=частини[1].toDouble(&коректнеЧисло);
            if(!коректнеЧисло||частини[0].trimmed().isEmpty()) continue;
            тимчасові[новаКількість].Назва=частини[0];
            тимчасові[новаКількість].Значення=qMax(0.0,число);
            тимчасові[новаКількість].Дата=частини[2];
            тимчасові[новаКількість].Опис=частини.mid(3).join(";");
            ++новаКількість;
        }
        файл.close();
        for(int i=0;i<новаКількість;++i) записи[i]=тимчасові[i];
        кількість=новаКількість; пошук->clear(); оновитиТаблицю();
        QMessageBox::information(this,QStringLiteral("Завантаження"),
            QStringLiteral("Завантажено записів: ")+QString::number(кількість));
    }
    void показатиДіаграму() {
        if(кількість==0) { QMessageBox::information(this,QStringLiteral("Діаграма"),QStringLiteral("Немає записів.")); return; }
        ВікноДіаграми *вікно=new ВікноДіаграми(записи,кількість);
        вікно->setAttribute(Qt::WA_DeleteOnClose); вікно->show();
    }
};
int main(int argc,char *argv[]) {
    QApplication застосунок(argc,argv);
    ГоловнеВікно вікно; вікно.show();
    return застосунок.exec();
}
